package com.example.PI_grupo_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiGrupo10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
