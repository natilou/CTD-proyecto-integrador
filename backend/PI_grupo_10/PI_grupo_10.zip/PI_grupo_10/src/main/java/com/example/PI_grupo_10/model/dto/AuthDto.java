package com.example.PI_grupo_10.model.dto;

public class AuthDto {
    public String email;
    public String token;
}
